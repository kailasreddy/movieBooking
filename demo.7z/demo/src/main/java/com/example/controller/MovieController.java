package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.MovieRepository;
import com.example.dao.ScreenRepository;
import com.example.dao.ShowRepository;
import com.example.dao.TheatreRepository;
import com.example.dto.Movie;
import com.example.dto.Screen;
import com.example.dto.Show;
import com.example.dto.Theatre;

@RestController
@CrossOrigin(origins = "*",allowedHeaders = "*")
public class MovieController {
@Autowired
TheatreRepository theatreRepository;
@Autowired
ScreenRepository screenRepository;
@Autowired
ShowRepository showRepository;
@Autowired
MovieRepository movieRepsitory;

@PostMapping("/addTheatre")
public List<Theatre> addTheatre(@RequestBody Theatre theatre){
	
	System.out.println("abc");
	Screen screen1=new Screen();
	screen1.setTheatre(theatre);
	screen1.setScreenNo(1);
	Show show1=new Show();
	show1.setShowTime("11:00AM");
	show1.setScreen(screen1);
	
	Show show2=new Show();
	show2.setShowTime("2:00PM");
	show2.setScreen(screen1);
	
	Movie movie1=new Movie();
	show1.setMovie(movie1);
	movie1.setShow(show1);
	
	Movie movie2=new Movie();
	show2.setMovie(movie2);
	movie2.setShow(show2);
	
	List<Show> showList=new ArrayList<>();
     showList.add(show1);
     showList.add(show2);
     screen1.setShows(showList);
     List<Screen> screenList=new ArrayList<>();
     screenList.add(screen1);
     theatre.setScreens(screenList);
     theatreRepository.save(theatre);
     return theatreRepository.findAll();
}

}
