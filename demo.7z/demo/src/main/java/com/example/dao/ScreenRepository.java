package com.example.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.dto.Screen;

public interface ScreenRepository extends JpaRepository<Screen, Integer> {

}
